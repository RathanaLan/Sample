package com.navigine.sdk.flutter;

public interface LifecycleListener {
    void onForeground();

    void onBackground();
}
