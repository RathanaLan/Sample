# navigine_sdk_example

![Flutter_example](https://github.com/Navigine/Indoor-Navigation-Flutter-SDK-2.0/blob/main/img/flutter_img_2.png)

Demonstrates how to use the navigine_sdk plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
