# Change Log
All notable changes to this project will be documented in this file.
`navigine_sdk` adheres to [Semantic Versioning](http://semver.org/).

## 1.2.8

* Fixed Metal DEPTH_TEST
* Fixed navigation algorighms
* Improved ssl certificate verification

## 1.2.7

* First release Navigine SDK with Flutter API